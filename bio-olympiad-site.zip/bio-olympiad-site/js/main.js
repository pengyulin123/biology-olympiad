/* =========================================================
 * BioOlympiad Lab · 交互层
 * 纯原生 JS，无依赖。负责：公共头尾注入、主题、各页渲染、题库判分
 * ======================================================= */

const NAV = [
  { href: "index.html", key: "home", label: "首页" },
  { href: "subjects.html", key: "subjects", label: "学科地图" },
  { href: "resources.html", key: "resources", label: "资源库" },
  { href: "quiz.html", key: "quiz", label: "题库训练" },
  { href: "plan.html", key: "plan", label: "备赛路线" }
];

const LS_PROGRESS = "bio.progress";
const LS_THEME = "bio.theme";

/* ---------------- 工具 ---------------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const el = (html) => {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
};

function store(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
}
function save(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

/* ---------------- 公共头尾 ---------------- */
function injectHeader() {
  const page = document.body.dataset.page;
  const host = $("#site-header");
  if (!host) return;
  host.className = "site-header";
  host.innerHTML = `
    <div class="wrap header-inner">
      <a class="brand" href="index.html">
        <span class="brand-mark">B</span>
        <span class="brand-text">
          <span>${SITE.nameCn}</span>
          <small>${SITE.name}</small>
        </span>
      </a>
      <button class="icon-btn nav-toggle" id="navToggle" aria-label="打开菜单" aria-expanded="false">☰</button>
      <nav class="nav" id="mainNav">
        ${NAV.map(n => `<a href="${n.href}" class="${n.key === page ? "active" : ""}">${n.label}</a>`).join("")}
      </nav>
      <button class="icon-btn" id="themeBtn" aria-label="切换深浅色" title="切换深浅色">◐</button>
    </div>`;
}

function injectFooter() {
  const host = $("#site-footer");
  if (!host) return;
  host.className = "site-footer";
  host.innerHTML = `
    <div class="wrap">
      <div class="footer-grid">
        <div>
          <h4>${SITE.nameCn} · ${SITE.name}</h4>
          <p>${SITE.tagline}</p>
          <p style="margin:0">目标：${SITE.target}</p>
        </div>
        <div>
          <h4>导航</h4>
          <ul>${NAV.map(n => `<li><a href="${n.href}">${n.label}</a></li>`).join("")}</ul>
        </div>
        <div>
          <h4>知识库</h4>
          <ul>${RESOURCES.slice(0, 5).map(r => `<li>${r.kb}</li>`).join("")}</ul>
        </div>
      </div>
      <div class="copyright">
        <span>© ${new Date().getFullYear()} ${SITE.nameCn} · 静态站点，托管于 GitHub Pages</span>
        <span>内容仅用于个人备赛学习，教材版权归原作者所有</span>
      </div>
    </div>`;
}

/* ---------------- 主题 & 菜单 ---------------- */
function bindChrome() {
  const btn = $("#themeBtn");
  const apply = (mode) => {
    document.documentElement.dataset.theme = mode;
    save(LS_THEME, mode);
  };
  if (btn) {
    btn.addEventListener("click", () => {
      apply(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
    });
  }
  const toggle = $("#navToggle");
  const nav = $("#mainNav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    $$("a", nav).forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
  }
}

/* ---------------- 首页 ---------------- */
function renderHome() {
  const stats = $("#statBar");
  if (stats) {
    stats.innerHTML = STATS.map(s => `<div class="stat"><b>${s.num}</b><span>${s.label}</span></div>`).join("");
  }

  const subjHost = $("#homeSubjects");
  if (subjHost) {
    subjHost.innerHTML = SUBJECTS.slice(0, 6).map(s => subjectCard(s)).join("");
  }

  const resHost = $("#homeResources");
  if (resHost) {
    resHost.innerHTML = RESOURCES.slice(0, 3).map(r => `
      <article class="card res-card">
        <div class="res-head"><h3 style="margin:0;font-size:1rem">${r.kb}</h3><span class="tag tag-brand">${r.tags[0]}</span></div>
        <p class="res-role">${r.role}</p>
        <p class="res-desc">${r.desc}</p>
      </article>`).join("");
  }

  const weekHost = $("#homeWeek");
  if (weekHost) {
    weekHost.innerHTML = `
      <table>
        <thead><tr><th>日</th><th>安排</th><th>类型</th></tr></thead>
        <tbody>
          ${WEEKLY.map(w => `<tr><td><b>${w.day}</b></td><td>${w.task}</td><td><span class="tag ${w.tag === "输出" ? "tag-accent" : "tag-brand"}">${w.tag}</span></td></tr>`).join("")}
        </tbody>
      </table>`;
  }
}

/* ---------------- 学科卡片 ---------------- */
function subjectCard(s) {
  const pct = Math.round((s.weight / 20) * 100);
  return `
    <article class="card subj-card" style="--c:${s.color}">
      <div class="subj-top">
        <h3>${s.name}</h3>
        <span class="subj-en">${s.en}</span>
      </div>
      <p class="subj-core">${s.core}</p>
      <div class="weight-bar"><i style="width:${pct}%"></i></div>
      <div class="subj-meta"><span>考查比重 ≈ ${s.weight}%</span><span>${s.points.length} 个核心考点</span></div>
      <details class="points">
        <summary>展开考点清单与推荐书目</summary>
        <ul>${s.points.map(p => `<li>${p}</li>`).join("")}</ul>
        <p style="font-size:.84rem;color:var(--muted);margin:8px 0 0">📚 ${s.books.join(" · ")}</p>
        <p class="hard-note">⚠ ${s.hard}</p>
      </details>
    </article>`;
}

/* ---------------- 学科地图页 ---------------- */
function renderSubjects() {
  const host = $("#subjectList");
  if (!host) return;
  host.innerHTML = SUBJECTS.map(s => subjectCard(s)).join("");

  const sumHost = $("#subjectSummary");
  if (sumHost) {
    sumHost.innerHTML = `
      <table>
        <thead><tr><th>模块</th><th>英文</th><th>比重</th><th>定位</th></tr></thead>
        <tbody>
          ${SUBJECTS.map(s => `<tr>
            <td><b style="color:${s.color}">${s.name}</b></td>
            <td style="color:var(--muted);font-size:.86rem">${s.en}</td>
            <td>≈ ${s.weight}%</td>
            <td style="font-size:.86rem">${s.core}</td>
          </tr>`).join("")}
        </tbody>
      </table>`;
  }
}

/* ---------------- 资源库页 ---------------- */
function renderResources() {
  const host = $("#resList");
  if (!host) return;

  const allTags = ["全部", ...new Set(RESOURCES.flatMap(r => r.tags))];
  const bar = $("#resFilter");
  bar.innerHTML = allTags.map((t, i) => `<button class="chip ${i === 0 ? "on" : ""}" data-tag="${t}">${t}</button>`).join("");

  const paint = (tag = "全部") => {
    const list = tag === "全部" ? RESOURCES : RESOURCES.filter(r => r.tags.includes(tag));
    host.innerHTML = list.map(r => `
      <article class="card res-card">
        <div class="res-head">
          <h3 style="margin:0;font-size:1.05rem">${r.kb}</h3>
          <div style="display:flex;gap:6px;flex-wrap:wrap">${r.tags.map(t => `<span class="tag tag-brand">${t}</span>`).join("")}</div>
        </div>
        <p class="res-role">${r.role}</p>
        <p class="res-desc">${r.desc}</p>
        ${r.folders ? `<p style="margin:0;font-size:.88rem"><b>文件夹：</b>${r.folders.join(" / ")}</p>` : ""}
        ${r.items ? `
          <details class="points">
            <summary>查看收录内容（${r.items.length} 类）</summary>
            <ul>${r.items.map(i => `<li>${i}</li>`).join("")}</ul>
          </details>` : ""}
        <p style="margin:0;font-size:.76rem;color:var(--muted);font-family:var(--mono)">${r.kbId}</p>
      </article>`).join("");
  };

  bar.addEventListener("click", (e) => {
    const btn = e.target.closest(".chip");
    if (!btn) return;
    $$(".chip", bar).forEach(c => c.classList.remove("on"));
    btn.classList.add("on");
    paint(btn.dataset.tag);
  });

  paint();
}

/* ---------------- 题库页 ---------------- */
function renderQuiz() {
  const host = $("#quizList");
  if (!host) return;

  const mods = ["全部", ...SUBJECTS.filter(s => QUESTIONS.some(q => q.module === s.id)).map(s => s.name)];
  const modMap = Object.fromEntries(SUBJECTS.map(s => [s.id, s.name]));
  const bar = $("#quizFilter");
  let current = "全部";

  bar.innerHTML = mods.map((m, i) => `<button class="chip ${i === 0 ? "on" : ""}" data-mod="${m}">${m}</button>`).join("");

  const paint = (mod) => {
    const list = mod === "全部" ? QUESTIONS : QUESTIONS.filter(q => modMap[q.module] === mod);
    host.innerHTML = list.map((q, i) => `
      <article class="card q-card" data-qid="${q.id}">
        <div class="q-head">
          <span class="q-index">Q${String(i + 1).padStart(2, "0")}</span>
          <span class="tag tag-brand">${modMap[q.module] || q.module}</span>
          <span class="tag">${q.level}</span>
        </div>
        <p class="q-stem">${q.stem}</p>
        <div class="opts">
          ${q.options.map((o, oi) => `
            <label class="opt">
              <input type="radio" name="q${q.id}" value="${oi}">
              <span><b>${"ABCD"[oi]}.</b> ${o}</span>
            </label>`).join("")}
        </div>
        <div class="explain" id="exp-${q.id}"><b>解析：</b>${q.explain}</div>
      </article>`).join("");
    updateScore();
  };

  const updateScore = () => {
    const cards = $$(".q-card", host);
    const answered = cards.filter(c => $("input:checked", c)).length;
    const right = cards.filter(c => c.dataset.state === "correct").length;
    $("#scoreLine").textContent = `已答 ${answered} / ${cards.length} · 正确 ${right}`;
    $("#accLine").textContent = answered ? `正确率 ${Math.round((right / answered) * 100)}%` : "";
  };

  host.addEventListener("change", (e) => {
    const input = e.target.closest("input[type=radio]");
    if (!input) return;
    const card = input.closest(".q-card");
    const q = QUESTIONS.find(x => x.id === Number(card.dataset.qid));
    const picked = Number(input.value);
    $$(".opt", card).forEach((lab, idx) => {
      lab.classList.remove("correct", "wrong");
      if (idx === q.answer) lab.classList.add("correct");
      else if (idx === picked) lab.classList.add("wrong");
    });
    card.dataset.state = picked === q.answer ? "correct" : "wrong";
    $("#exp-" + q.id).classList.add("show");
    updateScore();
  });

  bar.addEventListener("click", (e) => {
    const btn = e.target.closest(".chip");
    if (!btn) return;
    $$(".chip", bar).forEach(c => c.classList.remove("on"));
    btn.classList.add("on");
    current = btn.dataset.mod;
    paint(current);
  });

  $("#resetQuiz")?.addEventListener("click", () => paint(current));

  paint(current);
}

/* ---------------- 备赛路线页 ---------------- */
function renderPlan() {
  const tl = $("#timeline");
  if (!tl) return;
  tl.innerHTML = STAGES.map(s => `
    <div class="tl-item">
      <div class="tl-period">${s.phase} · ${s.period}</div>
      <h3>${s.title}</h3>
      <p style="color:var(--muted);font-size:.92rem">目标：${s.goal}</p>
      <ul>${s.tasks.map(t => `<li>${t}</li>`).join("")}</ul>
      <span class="milestone">◆ 阶段验收：${s.milestone}</span>
    </div>`).join("");

  const wh = $("#weekTable");
  if (wh) {
    wh.innerHTML = `
      <table>
        <thead><tr><th>日</th><th>安排</th><th>类型</th></tr></thead>
        <tbody>${WEEKLY.map(w => `<tr><td><b>${w.day}</b></td><td>${w.task}</td><td><span class="tag ${w.tag === "输出" ? "tag-accent" : "tag-brand"}">${w.tag}</span></td></tr>`).join("")}</tbody>
      </table>`;
  }

  const ph = $("#progressList");
  if (ph) {
    const prog = store(LS_PROGRESS, {});
    ph.innerHTML = STAGES.map((s, i) => `
      <label class="opt" style="cursor:pointer">
        <input type="checkbox" data-stage="${i}" ${prog[i] ? "checked" : ""}>
        <span><b>${s.phase}</b>　${s.title}<br><small style="color:var(--muted)">${s.period}</small></span>
      </label>`).join("");
    ph.addEventListener("change", () => {
      const next = {};
      $$("input[data-stage]", ph).forEach(i => { if (i.checked) next[i.dataset.stage] = true; });
      save(LS_PROGRESS, next);
    });
  }
}

/* ---------------- 启动 ---------------- */
document.addEventListener("DOMContentLoaded", () => {
  injectHeader();
  injectFooter();
  bindChrome();

  const page = document.body.dataset.page;
  if (page === "home") renderHome();
  if (page === "subjects") renderSubjects();
  if (page === "resources") renderResources();
  if (page === "quiz") renderQuiz();
  if (page === "plan") renderPlan();
});
