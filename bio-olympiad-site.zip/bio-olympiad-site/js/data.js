/* =========================================================
 * BioOlympiad Lab · 站点数据层
 * 所有页面内容集中在这里，改数据即可改站，不用动 HTML。
 * 说明：分值为经验参考（非官方），可在 subjects.weight 调整。
 * ======================================================= */

const SITE = {
  name: "BioOlympiad Lab",
  nameCn: "生竞研习室",
  tagline: "从零基础到省队：可检索、可训练、可追踪的生物竞赛工作台",
  owner: "高一 · 湖南",
  startDate: "2026-11",
  target: "2027 全国中学生生物学联赛 → 省队 → 国赛",
  year: 2027
};

/* ---------- 1. 学科模块（按竞赛考查范围拆解） ---------- */
const SUBJECTS = [
  {
    id: "cell",
    name: "细胞生物学",
    en: "Cell Biology",
    weight: 10,
    color: "#2f9e6e",
    core: "细胞结构与功能、膜运输、细胞骨架、细胞周期与凋亡、细胞信号转导",
    points: [
      "细胞膜结构与跨膜运输（泵、通道、协同运输）",
      "内膜系统与蛋白质分选（信号肽、共翻译转运）",
      "线粒体与叶绿体的结构与氧化磷酸化/光合磷酸化",
      "细胞骨架（微管、微丝、中间纤维）与马达蛋白",
      "细胞周期调控（cyclin-CDK、检查点）与细胞凋亡途径",
      "细胞连接、细胞外基质",
      "细胞信号转导：GPCR、RTK、第二信使"
    ],
    books: ["《细胞》科学出版社", "Cell Biology: A Laboratory Handbook Vol.4", "Molecular Biology of the Cell（进阶）"],
    hard: "膜电位计算、信号通路级联放大倍数的定量题是失分重灾区。"
  },
  {
    id: "biochem",
    name: "生物化学与分子生物学",
    en: "Biochemistry & Molecular Biology",
    weight: 17,
    color: "#3a7bd5",
    core: "蛋白质结构与酶学、代谢途径与调控、DNA 复制转录翻译、基因表达调控",
    points: [
      "氨基酸性质、蛋白质各级结构与折叠",
      "酶动力学（Km、Vmax、抑制类型判断）、别构调节、催化机制",
      "糖酵解、三羧酸循环、氧化磷酸化、糖异生、磷酸戊糖途径",
      "脂代谢、氨基酸代谢、核苷酸代谢",
      "DNA 复制、损伤修复、重组",
      "转录与 RNA 加工、翻译与翻译后修饰",
      "原核/真核基因表达调控（操纵子、增强子、表观遗传）"
    ],
    books: ["Structure and Mechanism in Protein Science (Fersht)", "Enzymes: Catalysis, Kinetics and Mechanisms (Punekar)", "Enzymes: A Practical Introduction (Copeland)", "Lehninger Principles of Biochemistry"],
    hard: "代谢流的定量推算、抑制剂类型的 Lineweaver-Burk 图判别、能量账目计算。"
  },
  {
    id: "plant",
    name: "植物解剖与生理",
    en: "Plant Anatomy & Physiology",
    weight: 13,
    color: "#4caf50",
    core: "植物组织与器官、水分与矿质运输、光合、激素、生长发育与生殖",
    points: [
      "分生组织、基本组织、维管组织与根茎叶的次生生长",
      "水分吸收与蒸腾、木质部/韧皮部运输（压力流学说）",
      "矿质营养与缺素症判断",
      "C3/C4/CAM 光合途径差异与光呼吸",
      "植物激素（生长素、赤霉素、细胞分裂素、ABA、乙烯、油菜素内酯）",
      "光形态建成与光周期、春化作用",
      "花器官发育（ABC 模型）、双受精与种子萌发"
    ],
    books: ["Plant Physiology (Taiz & Zeiger)", "《植物生理学》", "Plants and Fungi (DK 图解)"],
    hard: "C4 与 CAM 的碳同化路径、韧皮部装载/卸载机制、激素相互作用是高频细节区。"
  },
  {
    id: "animal",
    name: "动物解剖与生理",
    en: "Animal Anatomy & Physiology",
    weight: 16,
    color: "#e0703c",
    core: "组织器官系统、循环呼吸、排泄渗透调节、神经与内分泌、免疫",
    points: [
      "四大基本组织与器官系统比较解剖",
      "循环系统：心脏电生理、心动周期、血压调节",
      "呼吸：气体交换、氧解离曲线与波尔效应",
      "排泄与渗透调节：肾单位、逆流倍增、ADH/醛固酮",
      "消化与营养吸收、能量代谢",
      "神经：静息电位与动作电位、突触传递、感觉与运动通路",
      "内分泌：下丘脑-垂体轴、血糖与钙磷调节",
      "免疫：先天/适应性免疫、抗体多样性、补体"
    ],
    books: ["《人体及动物生理学》", "《神经生物学》", "神经科学原理 (Kandel 4th)", "《免疫学原理》"],
    hard: "肾单位各段物质转运方向、动作电位离子流时序、激素反馈通路图必须能默画。"
  },
  {
    id: "behavior",
    name: "动物行为学",
    en: "Animal Behavior",
    weight: 4,
    color: "#9c6ade",
    core: "行为的近因与远因、学习行为、社群行为、性选择与通讯",
    points: [
      "先天行为与学习行为（习惯化、印痕、试错、洞察）",
      "行为的四个问题（机制、发育、功能、进化）",
      "领域行为、等级制、利他与亲缘选择（Hamilton 法则）",
      "性选择与配偶选择、婚配制度",
      "通讯信号与信号诚实性",
      "迁徙与定向、生物钟"
    ],
    books: ["《生态学与动物行为学》", "Animal Behavior (Alcock)"],
    hard: "亲缘选择与博弈论的情境判断题，容易只凭直觉选错。"
  },
  {
    id: "genetics",
    name: "遗传学与进化",
    en: "Genetics & Evolution",
    weight: 15,
    color: "#d94f70",
    core: "孟德尔遗传、连锁交换、群体遗传、突变与染色体畸变、进化机制",
    points: [
      "分离定律、自由组合、复等位基因、致死基因",
      "连锁与交换、三点测交、基因定位与作图",
      "性别决定与伴性遗传、母性影响",
      "染色体结构/数目畸变、核型分析",
      "基因突变、重组、转座子",
      "数量性状与遗传率",
      "群体遗传：Hardy-Weinberg、选择、漂变、迁移、突变",
      "物种形成、系统发生与分子进化"
    ],
    books: ["《遗传学》刘祖洞", "《遗传学》戴灼华", "Principles of Genetics (Tamarin)", "Lewin's Genes XII", "《表观遗传学》(Allis)"],
    hard: "概率计算与三点测交是硬功夫；HW 平衡的变形条件（选择/近交）要分类讨论。"
  },
  {
    id: "ecology",
    name: "生态学",
    en: "Ecology",
    weight: 9,
    color: "#3aa6a6",
    core: "个体-种群-群落-生态系统、种间关系、物质循环与能量流动、保护生物学",
    points: [
      "种群增长模型（指数、逻辑斯谛）、生命表与存活曲线",
      "种间关系：竞争（Lotka-Volterra、竞争排斥）、捕食、寄生、互利",
      "生态位与资源分配",
      "群落结构、演替（初生/次生）、边缘效应",
      "生态系统能量流动（十分之一定律）、生产力",
      "碳氮磷循环、生物富集",
      "生物多样性梯度与保护策略"
    ],
    books: ["《基础生态学》牛翠娟", "Ecology (Cain/Bowman)"],
    hard: "模型参数含义与曲线形状的对应关系，以及演替阶段的判别。"
  },
  {
    id: "taxonomy",
    name: "生物系统学与分类",
    en: "Systematics & Taxonomy",
    weight: 8,
    color: "#8a7f52",
    core: "分类学原理、各主要类群特征与代表生物、系统发生树",
    points: [
      "双名法、分类阶元、模式标本",
      "支序系统学：单系/并系/多系、共有衍征",
      "原生生物、真菌、藻类主要类群",
      "苔藓、蕨类、裸子、被子植物的关键特征与生活史",
      "无脊椎动物各门（海绵、刺胞、扁形、环节、软体、节肢、棘皮）",
      "脊索动物的演化与各纲特征",
      "常见科属识别（湖南本地植物/昆虫）"
    ],
    books: ["《植物学》", "《普通动物学》", "《幼虫分类学》", "《中国外来入侵植物彩色图鉴》"],
    hard: "记忆量最大的模块，必须靠实物观察＋检索表练习，纯背必忘。"
  },
  {
    id: "micro",
    name: "微生物学",
    en: "Microbiology",
    weight: 5,
    color: "#5b8c3a",
    core: "原核/真核微生物、病毒、生长与代谢、致病与免疫、微生物生态",
    points: [
      "细菌细胞壁（革兰氏阳性/阴性）、鞭毛、芽孢、质粒",
      "微生物营养类型、生长曲线、环境因子影响",
      "病毒结构与复制周期（噬菌体、动物病毒）",
      "真菌与放线菌、古菌的特点",
      "消毒灭菌与抗生素作用机制",
      "微生物在物质循环与工业中的应用"
    ],
    books: ["Microbiology (Wiley 3rd)", "Fields Virology 8th", "Molecular and Cellular Biology of Viruses", "《现代微生物遗传学》"],
    hard: "病毒复制周期的细节与时序、抗生素靶点对应关系。"
  },
  {
    id: "biotech",
    name: "生物技术与实验",
    en: "Biotechnology & Lab Skills",
    weight: 3,
    color: "#607d8b",
    core: "分子克隆、PCR、测序、电泳、显微技术、实验设计与数据分析",
    points: [
      "限制酶、连接酶、载体与转化、蓝白斑筛选",
      "PCR 原理与引物设计、qPCR、测序（Sanger/NGS）",
      "凝胶电泳、Southern/Northern/Western",
      "显微技术与制片、染色原理",
      "层析、离心、分光光度法",
      "实验设计：对照、变量、误差分析、统计检验"
    ],
    books: ["《现代生物工程》", "《生物信息学：机器学习方法》", "Molecular Cloning（工具书）"],
    hard: "实验题往往以图/表形式出现，考的是读数和推断能力，不是背书。"
  }
];

/* ---------- 2. 资源中心：五个知识库的真实内容映射 ---------- */
const RESOURCES = [
  {
    kb: "生物竞赛AI助教",
    kbId: "ima_kb_rpj2P7ls",
    role: "真题与讲义主入口",
    desc: "三个核心文件夹：广东省竞赛试题、联赛试题、竞赛教材。日常刷题与对答案的起点。",
    folders: ["广东省竞赛试题", "联赛试题", "竞赛教材"],
    tags: ["真题", "讲义"]
  },
  {
    kb: "生物竞赛权威英文教材",
    kbId: "ima_kb_3NSBo3t2",
    role: "英文原版深度阅读",
    desc: "以酶学、物化、微生物、病毒学、发育生物学原版专著为主，适合专题攻坚时精读单章。",
    items: [
      "Structure and Mechanism in Protein Science (Fersht)",
      "Enzymes: Catalysis, Kinetics and Mechanisms (Punekar)",
      "Enzymes: A Practical Introduction (Copeland)",
      "Catalysis in Chemistry and Enzymology (Jencks)",
      "Physical Chemistry for the Chemical and Biological Sciences (Chang)",
      "Atkins' Physical Chemistry 11th",
      "Chemistry³ (Burrows)",
      "Fields Virology 8th",
      "Microbiology (Wiley 3rd)",
      "Molecular and Cellular Biology of Viruses (CRC 2024)",
      "Plants and Fungi (DK 2024)",
      "Open Questions in Developmental Biology"
    ],
    tags: ["英文教材", "专题"]
  },
  {
    kb: "大学生物学",
    kbId: "ima_kb_nZOKWEnD",
    role: "中文主干教材库",
    desc: "细胞、遗传、生理、神经、免疫、生态的中文教材集中地，打基础阶段的主力。",
    items: [
      "《细胞》科学出版社",
      "细胞生物学",
      "遗传学原理 Principles of Genetics (Tamarin)",
      "Lewin 基因 XII",
      "遗传学（刘祖洞 / 戴灼华）",
      "基因论（摩尔根）",
      "现代微生物遗传学",
      "表观遗传学（Allis）",
      "神经生物学 / 神经科学原理 4th",
      "人体及动物生理学",
      "免疫学原理",
      "基础生态学（牛翠娟）",
      "生态学与动物行为学",
      "现代生物工程",
      "生物信息学：机器学习方法",
      "生命的起源与演化"
    ],
    tags: ["中文教材", "基础"]
  },
  {
    kb: "生物竞赛AI知识库",
    kbId: "ima_kb_Pmagc34n",
    role: "分类学与图谱资源",
    desc: "国家地理动物百科（鱼/鸟/兽）、兰花与植物图鉴、细胞实验手册，系统学模块的图源。",
    items: [
      "Cell Biology: A Laboratory Handbook Vol.4",
      "国家地理动物百科全书（鱼类 / 鸟类 / 兽类全系列）",
      "中国常见贸易兰花识别手册",
      "蝴蝶兰遗传的机制",
      "大量 EPUB 图谱类资料"
    ],
    tags: ["图谱", "分类"]
  },
  {
    kb: "生物学知识库",
    kbId: "ima_kb_hYnNZjeh",
    role: "前沿期刊与拓展",
    desc: "Nature、Science、Scientific American、New Scientist、American Scientist 等期刊汇集，用于跟进前沿与出题素材。",
    items: [
      "Nature",
      "Science",
      "Science News",
      "Scientific American",
      "American Scientist",
      "New Scientist",
      "中国营养科学全书",
      "中国外来入侵植物彩色图鉴",
      "生物演讲范文"
    ],
    tags: ["期刊", "前沿"]
  }
];

/* ---------- 3. 题库（示例 12 题，含解析） ---------- */
const QUESTIONS = [
  {
    id: 1, module: "biochem", level: "基础",
    stem: "氰化物剧毒的原因是它抑制了细胞色素 c 氧化酶。该酶位于",
    options: ["线粒体外膜", "线粒体内膜", "线粒体基质", "细胞质基质"],
    answer: 1,
    explain: "细胞色素 c 氧化酶（复合体Ⅳ）嵌于线粒体内膜，负责把电子传给 O₂ 并泵出质子。氰化物与其 Fe³⁺ 结合后，电子传递链中断，氧化磷酸化停摆，细胞因 ATP 枯竭死亡。"
  },
  {
    id: 2, module: "biochem", level: "进阶",
    stem: "某酶促反应中，[S] 远大于 Km 时，反应速率主要受什么限制？",
    options: ["底物浓度", "酶的总量（Vmax）", "Km 值大小", "温度"],
    answer: 1,
    explain: "米氏方程 v = Vmax[S]/(Km+[S])，当 [S]≫Km 时 v≈Vmax，酶活性位点已饱和，速率只取决于酶量（Vmax = kcat[E]t）。"
  },
  {
    id: 3, module: "cell", level: "基础",
    stem: "关于 Na⁺-K⁺ 泵，下列说法正确的是",
    options: [
      "每消耗 1 分子 ATP，泵出 3 个 Na⁺、泵入 2 个 K⁺",
      "顺浓度梯度运输，不耗能",
      "每消耗 1 分子 ATP，泵出 2 个 Na⁺、泵入 3 个 K⁺",
      "只存在于神经元"
    ],
    answer: 1,
    explain: "Na⁺-K⁺ ATP 酶每水解 1 个 ATP，将 3 Na⁺ 泵出、2 K⁺ 泵入，形成净外正内负的电位贡献，几乎存在于所有动物细胞的质膜上。"
  },
  {
    id: 4, module: "plant", level: "进阶",
    stem: "C4 植物比 C3 植物在高温强光下光合效率更高的根本原因是",
    options: [
      "C4 植物叶绿体更大",
      "PEP 羧化酶对 CO₂ 亲和力高，且在空间上隔离了 Rubisco 与 O₂",
      "C4 植物不进行卡尔文循环",
      "C4 植物气孔永不关闭"
    ],
    answer: 1,
    explain: "C4 植物先在叶肉细胞用 PEP 羧化酶（对 CO₂ 亲和力远高于 Rubisco、不受 O₂ 竞争）固定 CO₂ 生成草酰乙酸，转运到维管束鞘细胞再释放 CO₂ 供 Rubisco 使用，形成“CO₂ 泵”，极大抑制光呼吸。"
  },
  {
    id: 5, module: "animal", level: "基础",
    stem: "抗利尿激素（ADH）促进水重吸收的主要作用部位是",
    options: ["肾小球", "近曲小管", "髓袢降支", "集合管"],
    answer: 3,
    explain: "ADH 作用于集合管主细胞 V2 受体，经 cAMP-PKA 使水通道蛋白 AQP2 插入顶端膜，提高集合管透水性，尿液浓缩。"
  },
  {
    id: 6, module: "animal", level: "进阶",
    stem: "动作电位去极化相的主要离子机制是",
    options: ["K⁺ 外流", "Na⁺ 内流", "Cl⁻ 内流", "Ca²⁺ 外流"],
    answer: 1,
    explain: "达到阈电位后电压门控 Na⁺ 通道大量开放，Na⁺ 顺电化学梯度内流导致去极化并形成超射；复极化则靠 K⁺ 外流。"
  },
  {
    id: 7, module: "genetics", level: "进阶",
    stem: "某常染色体隐性遗传病在人群中的发病率为 1/10000，假定群体处于 Hardy-Weinberg 平衡，则携带者频率约为",
    options: ["1/100", "1/50", "1/200", "1/10000"],
    answer: 1,
    explain: "q²=1/10000 → q=0.01，p=0.99；携带者频率 2pq=2×0.99×0.01≈0.0198≈1/50。注意隐性病携带者频率约为发病率的平方根的两倍，这就是“罕见病携带者并不罕见”的原因。"
  },
  {
    id: 8, module: "genetics", level: "基础",
    stem: "一对表现正常的夫妇生下一个患红绿色盲的儿子，最可能的解释是",
    options: ["父亲是携带者", "母亲是携带者，儿子从母亲获得致病 X 染色体", "常染色体显性突变", "儿子是新发突变，与父母无关"],
    answer: 1,
    explain: "红绿色盲为 X 连锁隐性。儿子 X 染色体必来自母亲，父亲传 Y；母亲表现正常说明她是杂合携带者（X^B X^b）。"
  },
  {
    id: 9, module: "ecology", level: "基础",
    stem: "下列组合中，最符合 r 选择生物特征的是",
    options: ["体型大、寿命长、后代少且亲代抚育强", "体型小、寿命短、产仔多、几乎无亲代抚育", "种群数量长期稳定在 K 值附近", "严格遵循逻辑斯谛增长"],
    answer: 1,
    explain: "r 选择者处于不稳定/多变环境，策略是把能量投入繁殖数量而非质量：体小、性成熟早、产仔多、无抚育。K 选择者与之相反。"
  },
  {
    id: 10, module: "behavior", level: "基础",
    stem: "刚孵化的小鹅会跟随第一眼看到的移动物体，这种行为称为",
    options: ["习惯化", "印痕（imprinting）", "经典条件反射", "洞察学习"],
    answer: 1,
    explain: "印痕发生在出生后的敏感期（关键期），一旦形成不可逆且难以更改，是“先天倾向＋特定经验窗口”结合的典型例子（Lorenz 的经典实验）。"
  },
  {
    id: 11, module: "micro", level: "进阶",
    stem: "革兰氏阴性菌对青霉素类较不敏感，主要结构原因是",
    options: [
      "细胞壁含大量肽聚糖",
      "外膜（含 LPS）屏障作用，且周质空间含 β-内酰胺酶",
      "没有细胞壁",
      "细胞膜含大量固醇"
    ],
    answer: 1,
    explain: "革兰氏阴性菌肽聚糖层薄，但外侧有脂多糖外膜阻挡药物渗透，周质空间还常有 β-内酰胺酶降解药物，双重保护。"
  },
  {
    id: 12, module: "taxonomy", level: "基础",
    stem: "被子植物特有的“双受精”是指",
    options: [
      "两个精子分别与卵细胞和中央细胞（极核）融合",
      "一个精子与两个卵细胞融合",
      "两个精子都与卵细胞融合",
      "精子和助细胞融合"
    ],
    answer: 0,
    explain: "一个精子与卵融合形成 2n 合子，另一个精子与中央细胞的两个极核融合形成 3n 胚乳，这是被子植物的标志性特征。"
  }
];

/* ---------- 4. 备赛路线（以 2027 联赛为锚点，可自行改期） ---------- */
const STAGES = [
  {
    phase: "阶段一",
    title: "基础夯实",
    period: "2026.11 — 2027.02",
    goal: "把高中生物 + 大学基础教材打通一遍，建立知识框架",
    tasks: [
      "通读 Campbell Biology（英文版对照中文），每章做 1 页概念图",
      "《细胞生物学》《遗传学》《人体及动物生理学》各过一遍主干",
      "每周 1 次植物/动物实物观察（校园、公园、菜市场均可取材）",
      "建立错题库：错因分四类——概念不清 / 细节遗忘 / 计算失误 / 读题误解"
    ],
    milestone: "完成 1 套完整联赛真题（限时），记录分数作为基线"
  },
  {
    phase: "阶段二",
    title: "专题突破",
    period: "2027.02 — 2027.04",
    goal: "按模块做深度攻坚，补齐生化与动物生理两块短板",
    tasks: [
      "每周 1 个专题：酶动力学 / 代谢 / 神经 / 免疫 / 植物激素 / 群体遗传",
      "每个专题精读一本英文专著的相关章节（知识库已备）",
      "刷广东省赛与各省真题，按模块统计正确率",
      "实验题专项：图像判读、数据表计算、实验设计三件套"
    ],
    milestone: "各模块正确率稳定在 70% 以上，弱项缩到 2 个以内"
  },
  {
    phase: "阶段三",
    title: "联赛冲刺",
    period: "2027.04 — 2027.05",
    goal: "以考代练，把速度、准确率、心态同时拉满",
    tasks: [
      "每周 2 套全真限时（严格计时，含涂卡）",
      "只看错题本，不再开新书",
      "分类学图谱每天 20 分钟闪卡记忆",
      "调整作息，把生物钟对到考试时段"
    ],
    milestone: "稳定进入省内前列，拿到省队选拔资格"
  },
  {
    phase: "阶段四",
    title: "省队/国赛",
    period: "2027.06 — 2027.08",
    goal: "应对实验考试与更高难度的理论卷",
    tasks: [
      "实验操作强化：显微制片、解剖、层析、电泳、分光光度",
      "读原版文献与综述，训练科研思维题",
      "历年国赛卷精做，重点攻多选与判断的细节陷阱"
    ],
    milestone: "省队入围 → 国赛冲击奖牌"
  }
];

/* ---------- 5. 每周节奏模板 ---------- */
const WEEKLY = [
  { day: "周一", task: "教材精读 2h（当周专题）", tag: "输入" },
  { day: "周二", task: "配套题 40 题 + 错题归档", tag: "输出" },
  { day: "周三", task: "英文专著单章 1.5h（慢读，做术语表）", tag: "输入" },
  { day: "周四", task: "实验/观察 2h（活体材料优先）", tag: "动手" },
  { day: "周五", task: "真题限时 1 套 + 精析", tag: "输出" },
  { day: "周六", task: "专题复盘：概念图重画 + 弱项补漏", tag: "复盘" },
  { day: "周日", task: "闪卡（分类/术语）+ 下周计划", tag: "维持" }
];

/* ---------- 6. 首页统计 ---------- */
const STATS = [
  { num: "10", label: "学科模块" },
  { num: "5", label: "知识库接入" },
  { num: "12", label: "示例题（可扩充）" },
  { num: "4", label: "备赛阶段" }
];
