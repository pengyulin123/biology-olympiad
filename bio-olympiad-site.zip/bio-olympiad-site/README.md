# 生竞研习室 · BioOlympiad Lab

面向**全国中学生生物学竞赛（CBO）**的个人备赛工作台。纯静态站点，零依赖、零构建，推到 GitHub 打开 Pages 即可上线。

> 定位：把「学科地图 + 资源索引 + 分模块题库 + 四阶段路线」做成一个能长期维护的系统，而不是一堆散落的笔记。

---

## 1. 站点结构

```
bio-olympiad-site/
├── index.html          首页：定位、统计、模块速览、每周节奏
├── subjects.html       学科地图：10 个模块 × 核心考点 × 书单 × 易错点
├── resources.html      资源库：5 个知识库的分工与取用顺序
├── quiz.html           题库训练：按模块筛选、即时判分、解析
├── plan.html           备赛路线：四阶段时间轴 + 周节奏 + 阶段打勾
├── 404.html
├── css/style.css       全部样式（CSS 变量，含深色模式）
├── js/data.js          ★ 内容数据层（改内容只改这里）
├── js/main.js          交互层（头尾注入、主题、渲染、判分）
├── assets/favicon.svg
└── .nojekyll           让 GitHub Pages 跳过 Jekyll 处理
```

**设计原则**：页面只写骨架，所有文字内容集中在 `js/data.js`。以后加教材、加题、改时间轴，都不用碰 HTML。

---

## 2. 本地预览

直接双击 `index.html` 也能用（数据用 `<script>` 引入，不走 fetch，没有跨域问题）。

需要本地服务器时：

```bash
cd bio-olympiad-site
python3 -m http.server 8000
# 浏览器打开 http://localhost:8000
```

---

## 3. 部署到 GitHub Pages

### 3.1 建仓库并推送

```bash
cd bio-olympiad-site
git init
git add .
git commit -m "init: 生物竞赛备赛站雏形"

# 先在 GitHub 网页端新建一个 public 仓库，例如 bio-olympiad（不要勾选初始化 README）
git branch -M main
git remote add origin https://github.com/<你的用户名>/bio-olympiad.git
git push -u origin main
```

### 3.2 开启 Pages

仓库页面 → **Settings** → 左侧 **Pages** →
**Source** 选 `Deploy from a branch` → **Branch** 选 `main` / `(root)` → **Save**。

约 1 分钟后访问：

```
https://<你的用户名>.github.io/bio-olympiad/
```

> 全站使用相对路径，放在子路径下不会出现样式丢失。若绑定自定义域名，在仓库根目录加 `CNAME` 文件写域名即可。

**另一种部署方式（可选）**：仓库内已带 `.github/workflows/pages.yml`。若你想用 Actions 部署，
把 **Settings → Pages → Source** 改成 `GitHub Actions`，之后每次 push 到 main 会自动构建发布。
两种方式二选一，不要同时开。

### 3.3 后续更新

```bash
git add . && git commit -m "add: 新增 20 道动物生理题" && git push
```

推送后 Pages 会自动重新构建。

---

## 4. 怎么扩内容

### 加一道题

编辑 `js/data.js` 的 `QUESTIONS` 数组：

```js
{
  id: 13, module: "animal", level: "进阶",        // module 取值见 SUBJECTS 的 id
  stem: "题干……",
  options: ["选项A", "选项B", "选项C", "选项D"],
  answer: 2,                                       // 正确项下标，从 0 开始
  explain: "解析……"
}
```

### 加一个学科模块

往 `SUBJECTS` 里加对象即可（`id / name / en / weight / color / core / points / books / hard`），学科地图、首页卡片、题库筛选会自动同步。

### 改备赛时间

`STAGES` 数组里改 `period` 与 `goal`；`SITE` 里改 `target` 与 `year`。

---

## 5. 建议的下一步（按性价比排序）

| 优先级 | 事项 | 做法 |
|---|---|---|
| P0 | 题目从 12 道扩到 200+ | 按模块补 `QUESTIONS`，先把联赛真题按知识点归档 |
| P0 | 错题本 | 用 `localStorage` 存错题 id，新增 `review.html` 只刷错题 |
| P1 | 全文搜索 | 内容量上来后，引入轻量索引（如 `minisearch`）或 GitHub 搜索 |
| P1 | 学习数据看板 | 记录每日刷题量、正确率，用 Canvas 画折线 |
| P2 | 评论/共建 | 接 Giscus（基于 GitHub Discussions），省后端 |
| P2 | CI 自动检查 | GitHub Actions 校验 `data.js` 的题目字段完整性、死链 |
| P2 | 与知识库联动 | 每道题挂 `kbId`，点击跳回 IMA 知识库原文 |

> 注意：GitHub Pages 只有静态能力。需要登录、多人写入、AI 答题，得换 Vercel/Cloudflare Workers + 数据库，或直接调用你自己的知识库 API。

---

## 6. 内容与版权

- 本站不托管、不分发任何教材正文与真题原件，只做**索引与训练**。
- 上列书目、真题、图鉴均指向个人知识库，阅读与引用请遵守版权规定。
- 站点文字为个人整理，欢迎 fork 改成自己的版本。

---

## 7. 数据来源

内容结构参考以下五个知识库的实际收录情况（教材名与分类真实对应）：

- 生物竞赛AI助教 —— 广东省竞赛试题 / 联赛试题 / 竞赛教材
- 生物竞赛权威英文教材 —— 酶学、物化、微生物、病毒学、发育生物学原版专著
- 大学生物学 —— 细胞、遗传、生理、神经、免疫、生态中文主干教材
- 生物竞赛AI知识库 —— 国家地理动物百科、兰科与植物图鉴、细胞实验手册
- 生物学知识库 —— Nature / Science / Scientific American 等期刊

**免责声明**：各模块「考查比重」为经验估计，非官方数据；联赛与省赛时间请以主办方正式通知为准。

---

MIT License · 自由取用与修改
